package com.example.clases;

import android.content.Context;
import android.database.Cursor;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CursorAdapter;
import android.widget.TextView;

import com.example.oscar.enbicia2.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by juanpablorn30 on 30/10/17.
 */

public class FriendsAdapter extends ArrayAdapter<Ciclista> implements View.OnClickListener {

    private List<Ciclista> dataSet;
    Context mContext;

    // View lookup cache
    private static class ViewHolder {
        TextView txtName;
        Button btnAgregar;
        Button btnEliminar;
    }

    public FriendsAdapter(List<Ciclista> data, Context context) {
        super(context, R.layout.list_search_friends, data);
        this.dataSet = data;
        this.mContext=context;
    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        if(id == R.id.btnAgregarAmigo){

        }else if(id == R.id.btnEliminarAmigo){

        }
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Ciclista dataModel = getItem(position);
        ViewHolder viewHolder;

        final View result;

        if (convertView == null) {

            viewHolder = new ViewHolder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.list_search_friends, parent, false);
            viewHolder.txtName = (TextView) convertView.findViewById(R.id.txtNombreAmigo);
            result=convertView;

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
            result=convertView;
        }
        viewHolder.txtName.setText(dataModel.getName());
        return convertView;
    }
}
