package com.example.clases;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Date;
import java.util.List;

/**
 * Created by juanpablorn30 on 2/10/17.
 */

public class Ciclista extends Usuario{

    private String estado;
    private Long cant_recorridos;
    private String numero_celular;
    private Long cant_amigos;

    /*
        TODO: Agregar método de agregar amigo.
        TODO: Agregar método de eliminar amigo.
     */
    private List<Ciclista> amigos;

    private List<Recorrido> historial;

    /*
        TODO: Agregar método de agregar a creados.
        TODO: Agregar método de eliminar de creados.
    */
    private List<Recorrido> creados;

    /*
        TODO: Agregar método de recibir mensajes.
        TODO: Agregar método de eliminar mensajes.
     */
    private List<Mensaje> bandejaEntrada;

    /*
        TODO: Agregar método de enviar mensajes.
        TODO: Agregar método de eliminar mensajes.
     */
    private List<Mensaje> bandejaSalida;

    public Ciclista() {
        super();
    }

    public Ciclista(String name, String email, Date date_birth) {
        super(name, email, date_birth);
        this.cant_recorridos = 0L;
        this.cant_amigos = 0L;
        this.numero_celular = "";
        this.estado = "";
    }

    public Ciclista(String name, String email, Date date_birth, String numero_celular) {
        super(name, email, date_birth);
        this.cant_recorridos = 0L;
        this.cant_amigos = 0L;
        this.numero_celular = numero_celular;
        this.estado = "";
    }

    public void agregarHistorial(Punto puntoInicio, Punto puntoFin){
        this.historial.add(new Recorrido(Constants.FINALIZADO, puntoInicio, puntoFin, this));
    }

    //TODO: Pensar como eliminar el recorrido, con que criterio.
    //TODO: ¿Interfaz debe tener botón de eliminar?. ¿Se puede eliminar?.
    public void eliminarHistorial(){

    }

    public void enviarMensaje(String contenido, Ciclista receptor){
        bandejaSalida.add(new Mensaje(contenido, receptor, this));
    }

    //[BEGIN GETTER AND SETTER Usuario]
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Long getDate_birth() {
        if(date_birth == null) return 0L;
        return date_birth.getTime();
    }

    public void setDate_birth(Date date_birth) {
        this.date_birth = date_birth;
    }
    //[END GETTER AND SETTER Usuario]


    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Long getCant_recorridos() {
        return cant_recorridos;
    }

    public void setCant_recorridos(Long cant_recorridos) {
        this.cant_recorridos = cant_recorridos;
    }

    public String getNumero_celular() {
        return numero_celular;
    }

    public void setNumero_celular(String numero_celular) {
        this.numero_celular = numero_celular;
    }

    public Long getCant_amigos() {
        return cant_amigos;
    }

    public void setCant_amigos(Long cant_amigos) {
        this.cant_amigos = cant_amigos;
    }

    public List<Ciclista> getAmigos() {
        return amigos;
    }

    public List<Recorrido> getHistorial() {
        return historial;
    }

    public List<Recorrido> getCreados() {
        return creados;
    }

    public List<Mensaje> getBandejaEntrada() {
        return bandejaEntrada;
    }

    public List<Mensaje> getBandejaSalida() {
        return bandejaSalida;
    }
}
