package com.example.clases;

/**
 * Created by juanpablorn30 on 3/10/17.
 */

public class TipoSitio {

    private String sitio;

    public TipoSitio(String sitio) {
        this.sitio = sitio;
    }

    public String getSitio() {
        return sitio;
    }

    public void setSitio(String sitio) {
        this.sitio = sitio;
    }
}
